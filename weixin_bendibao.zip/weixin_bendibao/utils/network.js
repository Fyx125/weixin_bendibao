// const network={

// }

// export {network}

module.exports=(url,data)=>{
  //wx.showLoading({ title: 'Loading...' });
  return new Promise((resolve,reject)=>{
    wx.request({
      url: `https://locally.uieee.com/${url}`,
      data,
      success: resolve,
      fail: reject,
    });
  })
}