// pages/list/list.js
const network = require('../../utils/network.js')
Page({

  /**
   * 页面的初始数据
   * category:当前加载的分类
   * shops：当前分类下的全部店铺
   */
  data: {
    category:{},
    shops:[],
    pageIndex:0,
    pageSize:10,
    hasMore:true,
    searchText:''
  },

  /**
   * 加载更多
   */
  loadMore(){
    if(!this.data.hasMore) return;
    let { pageIndex, pageSize, searchText}=this.data;
    console.log(searchText)
    const params = { _page: ++pageIndex, _limit: pageSize };
    if(searchText) params.q=searchText;
    return network(`categories/${this.data.category.id}/shops`,params)
    .then(res => {
      const totalCount = parseInt(res.header['X-Total-Count']);
      const hasMore=pageIndex*pageSize<totalCount
      let shops=this.data.shops.concat(res.data);
      this.setData({
        shops:shops,
        pageIndex:pageIndex,
        hasMore:hasMore
      });
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    network(`categories/${options.cat}`).then(res=>{
      this.setData({
        category:res.data
      });
      wx.setNavigationBarTitle({
        title: res.data.name,
      })
      this.loadMore();
    })
    //console.log(options)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    if(this.data.category.name){
      wx.setNavigationBarTitle({
        title: this.data.category.name,
      });
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.setData({shops:[],pageIndex:0,hasMore:true,searchText:''});
    this.loadMore().then(() => wx.stopPullDownRefresh());
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.loadMore();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 搜索处理
   */
  searchHandle(event) {
    var searchText = event.detail.value;
    //console.log(searchText);
    this.setData({ shops: [], pageIndex: 0, hasMore: true,searchText:searchText})
    this.loadMore();
  }
})