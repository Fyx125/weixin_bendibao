//index.js
const network=require('../../utils/network.js')
//获取应用实例
const app = getApp()

Page({
  data: {
    slides:[],
    categories:[]
  },
  onLoad: function () {
    network('slides').then(res=>{
        this.setData({
          slides: res.data
        })
       //console.log(items)
    });
    network('categories').then(res => {
      this.setData({
        categories: res.data
      })
      //console.log(items)
    });
  },
})
