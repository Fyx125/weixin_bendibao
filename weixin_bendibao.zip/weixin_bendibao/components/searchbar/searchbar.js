// components/searchbar/searchbar.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    
  },

  /**
   * 组件的方法列表
   */
  methods: {
    searchHandle(e) {
      var value = e.detail.value;
      var searchText = { "value": value };
      this.triggerEvent("searchinput", searchText);
      //console.log(e.detail.value)
    },
    showSearchHandle() {
      this.setData({ searchShowed: true })
    },
    hideSearchHandle() {
      this.setData({ searchText: '', searchShowed: false })
    },
    clearSearchHandle() {
      this.setData({ searchText: '' })
    },
    searchChangeHandle(e) {
      this.setData({ searchText: e.detail.value })
    }
  }
})
